This project is an isometric shooter game made in C# using the MonoGame framework.

The game was made with a team of 3 other students as a final project for the Game Development and Algorithmic Problem Solving II course.

Included in the "Level Editor" folder is a level editor which can be used to create fully functioning levels as txt files that may then be
put in the game's "Levels" folder to be played.

The game's controls are fairly simple:
WASD movement/mouse aiming
LMB to shoot
Shift to sprint